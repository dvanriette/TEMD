package org.example;

public class User {
    String username;
    String password;
    int guesses = 0;
    boolean wonGame = false;
}
