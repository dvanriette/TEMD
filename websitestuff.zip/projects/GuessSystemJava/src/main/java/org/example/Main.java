package org.example;


import org.json.JSONObject;

public class Main {

    public static void main(String[] args) {
        JSONObject jo = new JSONObject();
        jo.put("name", "jon doe");
        jo.put("age", "22");

    }
    public static void checkGuess(JSONObject guess, JSONObject answer){
        Boolean[] matches = {false,false,false,false,false,false};
        if(guess.get("name").equals(answer.get("name"))){
            for (int i = 0; i < matches.length; i++) {
                matches[i] = true;
                //winGame() // function to stop the game
            }
        }else {
            if (guess.get("diet").equals(answer.get("diet"))) {
                matches[1] = true;
            }
            if (guess.get("type").equals(answer.get("type"))) {
                matches[2] = true;
            }
            if (guess.get("habitat").equals(answer.get("habitat"))) {
                matches[3] = true;
            }
            if (guess.get("species").equals(answer.get("species"))) {
                matches[4] = true;
            }
            if (guess.get("pet").equals(answer.get("pet"))) {
                matches[5] = true;
            }
        }
        //setGuessAttributes(guess,matches)  //function needs to be made that connects to the html
        //if the value is false set the corresponding box to either red if its true set to green. visual clarity
    }
}